If[!ValueQ[$SpinorsPath],Quit[1]]
