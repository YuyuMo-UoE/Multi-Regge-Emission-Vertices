(* ::Package:: *)

(* ::Subsubsection:: *)
(*one emission*)


PEVu[qM,qP][q1p_,q1pb_]:=I


PEVu[qP,qM][q1p_,q1pb_]:=I


PEVu[M,P][q1p_,q1pb_]:=1


PEVu[P,M][q1p_,q1pb_]:=1


PEVd[qM,qP][n_]:=I Sqrt[P[n,"\[Perpendicular]*"]/P[n,"\[Perpendicular]"]]


PEVd[qP,qM][n_]:=-I Sqrt[P[n,"\[Perpendicular]"]/P[n,"\[Perpendicular]*"]]


PEVd[M,P][n_]:=P[n,"\[Perpendicular]*"]/P[n,"\[Perpendicular]"]


PEVd[P,M][n_]:=P[n,"\[Perpendicular]"]/P[n,"\[Perpendicular]*"]


PEVu[M,Pc][q1p_,q1pb_]:=-1


PEVu[P,Mc][q1p_,q1pb_]:=-1


PEVu[qM,qP][q1p_,q1pb_]:=I


PEVu[qP,qM][q1p_,q1pb_]:=I


PEVu[M,Pc][q1p_,q1pb_]:=-1


checkfn=PEVu[M,Pc];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVu[P,Mc][q1p_,q1pb_]:=-1


checkfn=PEVu[P,Mc];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVu[qM,qP][q1p_,q1pb_]:=I


checkfn=PEVu[qM,qP];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVu[qP,qM][q1p_,q1pb_]:=I


checkfn=PEVu[qP,qM];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVu[qP,qMc][q1p_,q1pb_]:=I


checkfn=PEVu[qP,qMc];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVu[qM,qPc][q1p_,q1pb_]:=I


checkfn=PEVu[qM,qPc];
x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/.P[l_,pl_]->P[xkc[l],pl]/.q[l_,pl_]->q[xkc[l],pl]/.xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;


PEVd[M,P][q1p_,q1pb_]:=q1p/q1pb


PEVd[P,M][q1p_,q1pb_]:=q1pb/q1p


PEVd[qP,qM][q1p_,q1pb_]:=-((I Sqrt[q1p])/Sqrt[q1pb])


PEVd[qM,qP][q1p_,q1pb_]:=-((I Sqrt[q1pb])/Sqrt[q1p])


PEVd[qP,qMc][q1p_,q1pb_]:=-((I Sqrt[q1p])/Sqrt[q1pb])


PEVd[qM,qPc][q1p_,q1pb_]:=-((I Sqrt[q1pb])/Sqrt[q1p])


PEVd[M,Pc][q1p_,q1pb_]:=-(q1pb/q1p)


PEVd[P,Mc][q1p_,q1pb_]:=-(q1p/q1pb)


(* ::Subsubsection:: *)
(*two emissions*)


PEVu[M,P,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1)/(q1p (1+X1-z1))
PEVu[P,M,M][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1b)/(q1pb (1+X1-z1b))


PEVu[P,M,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^3 z1)/(q1p (1+X1)^2 (1+X1-z1))
PEVu[M,P,M][X1_,q1pb_,q1p_,z1b_,z1_]:=PEVu[P,M,P][X1,q1p,q1pb,z1,z1b]



PEVu[P,P,M][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1)/(q1p (1+X1)^2 (1+X1-z1))


PEVu[M,M,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1b)/(q1pb (1+X1)^2 (1+X1-z1b))


PEVu[P,qP,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^(3/2) z1)/(q1p (1+X1)^2 (1+X1-z1))


PEVu[P,qM,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^(5/2) z1)/(q1p (1+X1)^2 (1+X1-z1)))





PEVu[M,qP,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^(5/2) z1b)/(q1pb (1+X1)^2 (1+X1-z1b)))
PEVu[M,qM,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^(3/2) z1b)/(q1pb (1+X1)^2 (1+X1-z1b))





PEVu[qM,qP,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1^(3/2) z1)/(q1p Sqrt[1+X1] (1+X1-z1))


PEVu[qP,qM,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1^(5/2) z1)/(q1p (1+X1)^(3/2) (1+X1-z1))





PEVu[qM,qP,M][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1^(5/2) z1b)/(q1pb (1+X1)^(3/2) (1+X1-z1b))


PEVu[qP,qM,M][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1^(3/2) z1b)/(q1pb Sqrt[1+X1] (1+X1-z1b))





PEVu[qP,P,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1 z1)/(q1p (1+X1)^(3/2) (1+X1-z1))


PEVu[qM,P,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1 z1)/(q1p Sqrt[1+X1] (1+X1-z1))


PEVu[qP,M,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1 z1b)/(q1pb Sqrt[1+X1] (1+X1-z1b))


PEVu[qM,M,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1 z1b)/(q1pb (1+X1)^(3/2) (1+X1-z1b))


getmomentumrep[checkfn_]:=Module[{x2c,motherfn},x2c=checkfn@@(checkfn//getargumentpev)//.backtomomentum[6]/. P[l_,pl_]->P[xkc[l],pl]/. q[l_,pl_]->q[xkc[l],pl]/. xkc[l_]:>ToExpression["xkc"<>ToString[l]];
motherfn="PEVup"<>StringDelete[ToString[axc@@(List@@checkfn)],"axc"]<>"[xkc3_,xkc4_]:="<>ToString[x2c//InputForm];
motherfn//ToExpression;]






PEVu[qP,qM,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I X1^(3/2) z1)/(q1p (1+X1)^(3/2)))


PEVu[qM,qP,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,qM,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qP,qM,Pc]];


getmomentumrep[PEVu[qM,qP,Mc]];





PEVu[qM,qP,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I Sqrt[X1] z1)/(q1p Sqrt[1+X1]))


PEVu[qP,qM,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,qP,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qM,qP,Pc]]
getmomentumrep[PEVu[qP,qM,Mc]]





PEVu[qM,P,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=(I z1)/(q1p Sqrt[1+X1])


PEVu[qP,M,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,P,qPc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qM,P,qPc]];
getmomentumrep[PEVu[qP,M,qMc]];





PEVu[qP,P,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=(I z1)/(q1p (1+X1)^(3/2))


PEVu[qM,M,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,P,qMc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qP,P,qMc]];
getmomentumrep[PEVu[qM,M,qPc]];





PEVu[P,qP,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=(Sqrt[X1] z1)/(q1p (1+X1)^2)


PEVu[M,qM,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qP,qMc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,qP,qMc]];
getmomentumrep[PEVu[M,qM,qPc]];





PEVu[P,qM,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^(3/2) z1)/(q1p (1+X1)^2))


PEVu[M,qP,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qM,qPc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,qM,qPc]];
getmomentumrep[PEVu[M,qP,qMc]];





PEVu[P,qMc,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^(5/2) z1)/(q1p (1+X1)^2 (1+X1-z1))


PEVu[M,qPc,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qMc,qPc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,qMc,qPc]]
getmomentumrep[PEVu[M,qPc,qMc]]





PEVu[P,qPc,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^(3/2) z1)/(q1p (1+X1)^2 (1+X1-z1)))


PEVu[M,qMc,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qPc,qMc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,qPc,qMc]];
getmomentumrep[PEVu[M,qMc,qPc]];





PEVu[qP,Pc,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I X1 z1)/(q1p (1+X1)^(3/2) (1+X1-z1)))


PEVu[qM,Mc,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,Pc,qMc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qP,Pc,qMc]];
getmomentumrep[PEVu[qM,Mc,qPc]];





PEVu[qM,Pc,qPc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I X1 z1)/(q1p Sqrt[1+X1] (1+X1-z1)))


PEVu[qP,Mc,qMc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,Pc,qPc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qM,Pc,qPc]];
getmomentumrep[PEVu[qP,Mc,qMc]];





PEVu[qM,qPc,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I X1^(3/2) z1)/(q1p Sqrt[1+X1] (1+X1-z1)))


PEVu[qP,qMc,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,qPc,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qM,qPc,Pc]];
getmomentumrep[PEVu[qP,qMc,Mc]];





PEVu[qP,qMc,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I X1^(5/2) z1)/(q1p (1+X1)^(3/2) (1+X1-z1)))


PEVu[qM,qPc,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,qMc,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qP,qMc,Pc]];
getmomentumrep[PEVu[qM,qPc,Mc]];





PEVu[P,M,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^2 z1)/(q1p (1+X1)^2))


PEVu[M,P,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,M,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,M,Pc]];
getmomentumrep[PEVu[M,P,Mc]];





PEVu[M,P,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=-(z1/q1p)


PEVu[P,M,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[M,P,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[M,P,Pc]];
getmomentumrep[PEVu[P,M,Mc]];





PEVu[P,P,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=-(z1/(q1p (1+X1)^2))


PEVu[M,M,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,P,Mc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,P,Mc]]
getmomentumrep[PEVu[M,M,Pc]]





PEVu[P,Pc,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1)/(q1p (1+X1)^2 (1+X1-z1))


PEVu[M,Mc,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,Pc,Mc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,Pc,Mc]];
getmomentumrep[PEVu[M,Mc,Pc]];





PEVu[P,Mc,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^3 z1)/(q1p (1+X1)^2 (1+X1-z1))


PEVu[M,Pc,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,Mc,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,Mc,Pc]];
getmomentumrep[PEVu[M,Pc,Mc]];





PEVu[M,Pc,Pc][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1 z1)/(q1p (1+X1-z1))


PEVu[P,Mc,Mc][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[M,Pc,Pc][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[M,Pc,Pc]];
getmomentumrep[PEVu[P,Mc,Mc]];





PEVu[M,Pc,P][X1_,q1p_,q1pb_,z1_,z1b_]:=-(z1/q1p)


PEVu[P,Mc,M][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[M,Pc,P][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[M,Pc,P]];
getmomentumrep[PEVu[P,Mc,M]];





PEVu[P,Mc,P][X1_,q1p_,q1pb_,z1_,z1b_]:=-((X1^2 z1)/(q1p (1+X1)^2))


PEVu[M,Pc,M][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,Mc,P][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,Mc,P]];
getmomentumrep[PEVu[M,Pc,M]];





PEVu[P,Pc,M][X1_,q1p_,q1pb_,z1_,z1b_]:=-(z1/(q1p (1+X1)^2))


PEVu[M,Mc,P][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,Pc,M][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[P,Pc,M]];
getmomentumrep[PEVu[M,Mc,P]];





PEVu[qP,qMc,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(I X1^(3/2) z1)/(q1p (1+X1)^(3/2))


PEVu[qM,qPc,M][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,qMc,P][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qP,qMc,P]];
getmomentumrep[PEVu[qM,qPc,M]];





PEVu[qM,qPc,P][X1_,q1p_,q1pb_,z1_,z1b_]:=(I Sqrt[X1] z1)/(q1p Sqrt[1+X1])


PEVu[qP,qMc,M][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,qPc,P][X1,q1pb,q1p,z1b,z1]


getmomentumrep[PEVu[qM,qPc,P]];
getmomentumrep[PEVu[qP,qMc,M]];





PEVu[P,qPc,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=-((Sqrt[X1] z1)/(q1p (1+X1)^2))


PEVu[M,qMc,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qPc,qM][X1,q1pb,q1p,z1b,z1]


fjsfn=PEVu[P,qPc,qM];
getmomentumrep[fjsfn];
getmomentumrep[toconjugate[fjsfn]];





PEVu[P,qMc,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=(X1^(3/2) z1)/(q1p (1+X1)^2)


PEVu[M,qPc,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[P,qMc,qP][X1,q1pb,q1p,z1b,z1]


fjsfn=PEVu[P,qMc,qP];
getmomentumrep[fjsfn];
getmomentumrep[toconjugate[fjsfn]];





PEVu[qM,Pc,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I z1)/(q1p Sqrt[1+X1]))


PEVu[qP,Mc,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qM,Pc,qP][X1,q1pb,q1p,z1b,z1]


fjsfn=PEVu[qM,Pc,qP];
getmomentumrep[fjsfn];
getmomentumrep[toconjugate[fjsfn]]





PEVu[qP,Pc,qM][X1_,q1p_,q1pb_,z1_,z1b_]:=-((I z1)/(q1p (1+X1)^(3/2)))


PEVu[qM,Mc,qP][X1_,q1p_,q1pb_,z1_,z1b_]:=PEVu[qP,Pc,qM][X1,q1pb,q1p,z1b,z1]


fjsfn=PEVu[qP,Pc,qM];
getmomentumrep[fjsfn];
getmomentumrep[toconjugate[fjsfn]];



