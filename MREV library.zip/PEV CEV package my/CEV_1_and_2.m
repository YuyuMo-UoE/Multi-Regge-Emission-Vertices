(* ::Package:: *)

(* ::Chapter:: *)
(*new 5 and 6*)


CEV[P][q1p_,q1pb_,z1_,z1b_]:=q1pb z1


CEV[M][q1p_,q1pb_,z1_,z1b_]:=q1p z1b


CEV[Pc][q1p_,q1pb_,z1_,z1b_]:=-q1pb z1


CEV[Mc][q1p_,q1pb_,z1_,z1b_]:=-q1p z1b


CEV[M,P][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(X2 (-1+z1b) z1b z2b)/((1+X2 z1) (1+X2 z1 z1b) (1+X2 z1 z1b-z2b))+(X2^3 (-1+z1) z1 (-1+z1b) z1b^4 z2)/((1+X2 z1b-z2b) (1+X2 z1 z1b-z2b) (1+X2 z1 z1b+z2 (-1+z2b)-z2b) (-1+z1b+z2b))+(X2^3 (-1+z1) z1 z1b z2 z2b)/((1+X2) (1+X2 z1) (1+X2 z1-z2) (-1+z1b+z2b))


CEV[P,M][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(X2 (-1+z1) z1 z2)/((1+X2 z1b) (1+X2 z1 z1b) (1+X2 z1 z1b-z2))+(X2^3 z1 (-1+z1b) z1b z2 z2b)/((1+X2) (1+X2 z1b) (-1+z1+z2) (1+X2 z1b-z2b))+(X2^3 (-1+z1) z1^4 (-1+z1b) z1b z2b)/((1+X2 z1-z2) (1+X2 z1 z1b-z2) (-1+z1+z2) (1+X2 z1 z1b-z2-z2b+z2 z2b))


CEVn[M,P][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=X2 z1b (((-1+z1b) (-1+z2)+X2^2 (-1+z1) z1 z1b z2-X2 (-1+z1b) (1+(-1+z1) z2))/((1+X2) (1+X2 z1 z1b) (1+X2 z1-z2))+((-1+z1b) (X2^2 z1b (1+(-2+z1+z1^2) z2-(-1+z1) z2^2)-X2 (-1+z2) (1+(-1+z1) z2) (1+z1b-z2b)-(-1+z2)^2 (-1+z2b)))/((1+X2) (1+X2 z1-z2) (1+X2 z1b-z2b) (1+X2 z1 z1b+z2 (-1+z2b)-z2b)))


CEVn[P,M][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEVn[M,P][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[P,P][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(q1pb X2 (-1+z1) z1 z2)/(q1p (1+X2 z1-z2))


CEV[M,M][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(q1p X2 (-1+z1b) z1b z2b)/(q1pb (1+X2 z1b-z2b))


CEV[Pc,M][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((z1 (-z2+z1 z2-X2^2 z1^2 z1b^2 z2b+X2^2 z1^2 z1b^3 z2b+2 z2 z2b-2 z1 z2 z2b-2 z1b z2 z2b+2 z1 z1b z2 z2b+X2 z1 z1b z2 z2b-X2 z1^2 z1b z2 z2b-X2 z1 z1b^2 z2 z2b+X2 z1^2 z1b^2 z2 z2b-z2 z2b^2+z1 z2 z2b^2+2 z1b z2 z2b^2-2 z1 z1b z2 z2b^2-X2 z1 z1b z2 z2b^2+X2 z1^2 z1b z2 z2b^2-z1b^2 z2 z2b^2+z1 z1b^2 z2 z2b^2+2 X2 z1 z1b^2 z2 z2b^2-2 X2 z1^2 z1b^2 z2 z2b^2-X2 z1 z1b^3 z2 z2b^2+X2 z1^2 z1b^3 z2 z2b^2))/(z1b (1+X2 z1 z1b) (1+X2 z1 z1b-z2+z1 z2-z2b+z1b z2b+z2 z2b-z1 z2 z2b-z1b z2 z2b+z1 z1b z2 z2b)))


CEV[Mc,P][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Pc,M][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[Pc,P][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((q1pb (-1+z1) z2)/q1p)


CEV[Mc,M][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Pc,P][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[Pc,Pc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[P,P][X2,q1p,q1pb,z1,z1b,z2,z2b]


CEV[Mc,Mc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Pc,Pc][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[P,Mc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Pc,M][X2,q1p,q1pb,z1,z1b,z2,z2b]


CEV[M,Pc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[P,Mc][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[P,Pc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Pc,P][X2,q1p,q1pb,z1,z1b,z2,z2b]


CEV[M,Mc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Mc,M][X2,q1p,q1pb,z1,z1b,z2,z2b]


CEV[Mc,Pc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[M,P][X2,q1p,q1pb,z1,z1b,z2,z2b]


CEV[Pc,Mc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=CEV[Mc,Pc][X2,q1pb,q1p,z1b,z1,z2b,z2]


CEV[qP,qM][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((X2^(5/2) z1^3 (-1+z1b) z1b z2b)/((1+X2 z1) (1+X2 z1 z1b) (1+X2 z1 z1b-z2b)))+(X2^(3/2) (-1+z1) z1 z1b z2 z2b)/((1+X2) (1+X2 z1) (1+X2 z1-z2) (-1+z1b+z2b))-(X2^(3/2) (-1+z1) z1 (-1+z1b) z1b z2 (-1+z2b)^3)/((1+X2 z1b-z2b) (1+X2 z1 z1b-z2b) (-1+z1b+z2b) (1+X2 z1 z1b-z2-z2b+z2 z2b))


CEV[qM,qP][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(X2^(3/2) z1 (-1+z1b) z1b z2b)/((1+X2 z1) (1+X2 z1 z1b) (1+X2 z1 z1b-z2b))-(X2^(5/2) (-1+z1) z1 z1b z2 z2b)/((1+X2) (1+X2 z1) (1+X2 z1-z2) (-1+z1b+z2b))+(X2^(5/2) (-1+z1) z1 (-1+z1b) z1b^3 z2 (-1+z2b))/((1+X2 z1b-z2b) (1+X2 z1 z1b-z2b) (-1+z1b+z2b) (1+X2 z1 z1b-z2-z2b+z2 z2b))


CEV[qM,qPc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((X2^(3/2) (-1+z1) z1 z1b^2 z2)/((1+X2 z1 z1b) (1+X2 z1 z1b-z2+z1 z2)))+(Sqrt[X2] (-1+z1b) z1b (1-z2+z1 z2)^2 z2b)/((1+X2 z1 z1b-z2+z1 z2) (1+X2 z1 z1b-z2+z1 z2-z2b+z1b z2b+z2 z2b-z1 z2 z2b-z1b z2 z2b+z1 z1b z2 z2b))


CEV[qP,qMc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(Sqrt[X2] (-1+z1) z1 z2)/((1+X2 z1 z1b) (1+X2 z1 z1b-z2+z1 z2))-(X2^(3/2) z1^2 (-1+z1b) z1b z2b)/((1+X2 z1 z1b-z2+z1 z2) (1+X2 z1 z1b-z2+z1 z2-z2b+z1b z2b+z2 z2b-z1 z2 z2b-z1b z2 z2b+z1 z1b z2 z2b))


CEV[qMc,qP][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((Sqrt[X2] (-1+z1b) z1b z2b)/((1+X2 z1 z1b) (1+X2 z1 z1b-z2b+z1b z2b)))+(X2^(3/2) (-1+z1) z1 z1b^2 z2)/((1+X2 z1 z1b-z2b+z1b z2b) (1+X2 z1 z1b-z2+z1 z2-z2b+z1b z2b+z2 z2b-z1 z2 z2b-z1b z2 z2b+z1 z1b z2 z2b))


CEV[qPc,qM][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(X2^(3/2) z1^2 (-1+z1b) z1b z2b)/((1+X2 z1 z1b) (1+X2 z1 z1b-z2b+z1b z2b))-(Sqrt[X2] (-1+z1) z1 z2 (1-z2b+z1b z2b)^2)/((1+X2 z1 z1b-z2b+z1b z2b) (1+X2 z1 z1b-z2+z1 z2-z2b+z1b z2b+z2 z2b-z1 z2 z2b-z1b z2 z2b+z1 z1b z2 z2b))


CEV[qPc,qMc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=-((X2^(3/2) (-1+z1) z1 z1b z2)/((1+X2 z1b) (1+X2 z1 z1b) (1+X2 z1 z1b-z2)))+(X2^(5/2) z1 (-1+z1b) z1b z2 z2b)/((1+X2) (1+X2 z1b) (-1+z1+z2) (1+X2 z1b-z2b))-(X2^(5/2) (-1+z1) z1^3 (-1+z1b) z1b (-1+z2) z2b)/((1+X2 z1-z2) (1+X2 z1 z1b-z2) (-1+z1+z2) (1+X2 z1 z1b-z2-z2b+z2 z2b))


CEV[qMc,qPc][X2_,q1p_,q1pb_,z1_,z1b_,z2_,z2b_]:=(X2^(5/2) (-1+z1) z1 z1b^3 z2)/((1+X2 z1b) (1+X2 z1 z1b) (1+X2 z1 z1b-z2))-(X2^(3/2) z1 (-1+z1b) z1b z2 z2b)/((1+X2) (1+X2 z1b) (-1+z1+z2) (1+X2 z1b-z2b))+(X2^(3/2) (-1+z1) z1 (-1+z1b) z1b (-1+z2)^3 z2b)/((1+X2 z1-z2) (1+X2 z1 z1b-z2) (-1+z1+z2) (1+X2 z1 z1b-z2-z2b+z2 z2b))
