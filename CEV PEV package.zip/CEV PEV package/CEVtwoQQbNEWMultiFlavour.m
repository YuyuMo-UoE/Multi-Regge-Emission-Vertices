(* ::Package:: *)

Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariADiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC1DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC2DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC3DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC4DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC12DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC13DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC14DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC23DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC24DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC34DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC123DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC134DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC124DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC234DiffFlavour.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEWmultiFlavour/"<>"CEVnnmhvTWOqqbPariC1234DiffFlavour.txt"]//ToExpression;
