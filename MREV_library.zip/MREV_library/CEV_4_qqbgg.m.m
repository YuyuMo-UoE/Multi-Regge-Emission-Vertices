(* ::Package:: *)

(* ::Subsubsection:: *)
(*8 point one quark pair*)


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"FourpartonCEVtable.m"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPari.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC1.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC2.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC3.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC4.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC12.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC13.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC14.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC23.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC24.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC34.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC123.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC124.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC134.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC234.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVoneQQbpari/"<>"CEVnnmhvONEqqbPariC1234.txt"]//ToExpression;
