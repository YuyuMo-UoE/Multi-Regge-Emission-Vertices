(* ::Package:: *)

Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariA.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC1.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC2.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC3.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC4.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC12.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC13.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC14.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC23.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC24.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC34.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC123.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC134.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC124.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC234.txt"]//ToExpression;


Import[NotebookDirectory[]<>"CEVtwoQQbpairsNEW/"<>"CEVnnmhvTWOqqbPariC1234.txt"]//ToExpression;
